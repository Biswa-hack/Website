Biswajit Cost & Advisory — Next.js project (production-ready scaffold)

What's included:
- app/ pages for Consultancy (home) and Coaching
- API route for bot (OpenAI integration example)
- External hero images (royalty-free suggestions)
- GA4 snippet and Search Console instructions
- Sitemap & robots endpoints

Setup:
1. Install: npm install
2. Run dev: npm run dev
3. Build: npm run build

GA4:
- Create a GA4 property in Google Analytics. Get the Measurement ID (G-XXXXXXXXXX).
- Add it into app/components/Analytics.tsx or directly into app/layout.tsx (example file included).
- Example script (replace MEASUREMENT_ID):
  <script async src={`https://www.googletagmanager.com/gtag/js?id=G-MEASUREMENT_ID`} />
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config','G-MEASUREMENT_ID');
  </script>

Search Console:
- Add your site in Google Search Console and verify ownership.
- You can verify by adding the meta tag into app/layout.tsx head:
  <meta name="google-site-verification" content="YOUR_VERIFICATION_TOKEN" />

OpenAI Bot integration:
- Create an environment variable OPENAI_API_KEY on your server/Vercel.
- The API route pages/api/openai-bot.ts contains example code that forwards queries to OpenAI securely.
- Set usage limits and caching as needed.

Deploy:
- Vercel recommended: connect this repo, set env vars (OPENAI_API_KEY), and deploy.

If you want, I can push this to your GitHub repo or produce further deployment configs.
