import { MetadataRoute } from 'next'
export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://yourdomain.com'
  return [
    { url: baseUrl, lastModified: new Date().toISOString() },
    { url: baseUrl + '/coaching', lastModified: new Date().toISOString() },
  ]
}
