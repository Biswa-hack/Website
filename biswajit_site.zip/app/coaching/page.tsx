'use client'
import React from 'react'
export default function Coaching() {
  // Coaching hero options:
  // Option A: Student takes notes: https://unsplash.com/photos/PYhfsKfGQok (direct image: https://images.unsplash.com/photo-1751366590-7b5f5e2f0d5b)
  const hero = 'https://images.unsplash.com/photo-1714385978758-12b0b5a0f5b9?auto=format&fit=crop&w=1400&q=80'
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-lg font-bold">Biswajit Cost & Advisory</h1>
            <p className="text-sm text-slate-500">Coaching • Exam prep • Practical labs</p>
          </div>
          <nav className="flex gap-4">
            <a href="/">Consultancy</a>
            <a href="/coaching">Coaching</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl font-extrabold">Professional Coaching & Classes</h2>
            <p className="mt-4 text-slate-600">Live batches, recorded modules, mock tests and placement guidance.</p>
            <div className="mt-6">
              <a className="btn" href="https://wa.me/917003406653?text=Hello%2C%20I%20want%20to%20join%20Coaching%20%26%20Batches" target="_blank" rel="noreferrer">Reserve via WhatsApp</a>
            </div>
          </div>

          <div>
            <img src={hero} alt="Coaching Hero" className="w-full h-64 object-cover rounded-xl shadow" />
          </div>
        </section>

        <section className="mt-12">
          <h3 className="text-2xl font-bold">Courses</h3>
          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-xl shadow">
              <h4 className="font-semibold">CMA Foundation to Final</h4>
              <p className="text-sm text-slate-500 mt-2">Structured syllabus, doubt clearing & mock tests.</p>
              <div className="mt-3"><a href="https://wa.me/917003406653?text=I%20want%20to%20enroll%20in%20CMA%20Coaching" target="_blank" rel="noreferrer">Enroll on WhatsApp</a></div>
            </div>

            <div className="bg-white p-4 rounded-xl shadow">
              <h4 className="font-semibold">Practical GST & Accounting Lab</h4>
              <p className="text-sm text-slate-500 mt-2">Hands-on with Tally & Excel case studies.</p>
              <div className="mt-3"><a href="https://wa.me/917003406653?text=I%20want%20to%20enroll%20in%20GST%20%26%20Accounting%20Lab" target="_blank" rel="noreferrer">Enroll on WhatsApp</a></div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-white py-6 mt-12">
        <div className="max-w-6xl mx-auto px-6 text-sm text-slate-500">© {new Date().getFullYear()} Biswajit Cost & Advisory</div>
      </footer>
    </div>
  )
}
