'use client'
import React from 'react'
export default function Home() {
  // Hero image options (choose one and replace in <img src="">)
  // Option A: Two businessmen reviewing documents
  // https://unsplash.com/photos/Kul6JqIDA3I (direct image: https://images.unsplash.com/photo-1598887142486-0f9e0c4b0b07)
  // Option B: Young accountant preparing reports
  // https://unsplash.com/photos/grglD40lEOI (direct image: https://images.unsplash.com/photo-1661956600655-5b4b9f3b6c7a)
  // Option C: Calculator on desk
  // https://unsplash.com/photos/8wLZi9OhsWU (direct image: https://images.unsplash.com/photo-1717187116163-5b2c9d7d9f8a)
  const hero = 'https://images.unsplash.com/photo-1598887142486-0f9e0c4b0b07?auto=format&fit=crop&w=1400&q=80'
  const placeholder = 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80'
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-lg font-bold">Biswajit Cost & Advisory</h1>
            <p className="text-sm text-slate-500">Accounting • Costing • Coaching</p>
          </div>
          <nav className="flex gap-4">
            <a href="/">Consultancy</a>
            <a href="/coaching">Coaching</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl font-extrabold">Consultancy & Accounting Services</h2>
            <p className="mt-4 text-slate-600">End-to-end financial systems that reduce cost and increase control.</p>
            <div className="mt-6 flex gap-3">
              <a className="btn" href="https://wa.me/917003406653?text=Hello%2C%20I%20am%20interested%20in%20General%20Consultancy" target="_blank" rel="noreferrer">Contact on WhatsApp</a>
            </div>
          </div>

          <div>
            <img src={hero} alt="Accounting Hero" className="w-full h-64 object-cover rounded-xl shadow" />
          </div>
        </section>

        <section className="mt-12">
          <h3 className="text-2xl font-bold">Services</h3>
          <div className="mt-6 grid md:grid-cols-2 gap-4">
            {['Product & Process Costing','Budgeting & Forecasting','Variance Analysis & MIS','Activity Based Costing'].map((s)=>(
              <div key={s} className="bg-white p-4 rounded-xl shadow flex gap-4 items-center">
                <img src={placeholder} className="w-20 h-20 object-cover rounded" alt="" />
                <div>
                  <h4 className="font-semibold">{s}</h4>
                  <div className="mt-2">
                    <a className="text-sm" href={`https://wa.me/917003406653?text=${encodeURIComponent('Hello, I am interested in '+s)}`} target="_blank" rel="noreferrer">Enquire on WhatsApp</a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-white py-6 mt-12">
        <div className="max-w-6xl mx-auto px-6 text-sm text-slate-500">© {new Date().getFullYear()} Biswajit Cost & Advisory</div>
      </footer>
    </div>
  )
}
