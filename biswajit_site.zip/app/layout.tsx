import './globals.css'
import React from 'react'
export const metadata = {
  title: 'Biswajit Cost & Advisory — Accounting, Costing & Coaching',
  description: 'Cost accounting, GST, audit and professional coaching. Practical training and enterprise-grade cost systems.',
}
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Replace with your Search Console token: <meta name="google-site-verification" content="YOUR_TOKEN" /> */}
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
