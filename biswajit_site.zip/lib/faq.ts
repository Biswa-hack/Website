export const services = [
  "Product & Process Costing",
  "Budgeting & Forecasting",
  "Variance Analysis & MIS",
  "Activity Based Costing",
  "Inventory Valuation & Controls",
  "GST & Tax Compliance",
  "Direct Tax Planning",
  "Internal Audit & Controls",
  "ERP Cost Module Setup",
  "Management Reporting & Dashboards",
];

export function botAnswer(query: string) {
  const t = query.toLowerCase();
  if (t.includes('price') || t.includes('cost') || t.includes('fee')) return 'Pricing depends on scope — small businesses start at ₹4,999/mo; corporate engagements are custom.';
  if (t.includes('gst') || t.includes('tax')) return 'We handle GST returns, notices and advisory. Which GST topic do you want help with?';
  if (t.includes('coach') || t.includes('class')) return 'Our coaching includes live classes, recorded modules and mock tests. Which course: CMA or Practical GST/Accounting?';
  if (t.includes('schedule') || t.includes('slot')) return 'Next batch starts Oct 6 • Evening batch (3 days/week). For consultancy slots, we have morning/afternoon options.';
  if (t.includes('hello') || t.includes('hi')) return 'Hello! How can I help you today?';
  return "Great question — we'll connect you with our advisor. You can also contact us on WhatsApp for a faster reply.";
}
